------------------ How to Execute ------------------
python3 main.py

------------------ How to Change Configuration ------------------
* All configuration information is included in the "config.py" file
* By default benchmark option is disabled and must be enabled only when 
  benchmarking with a script to minimize the stdout information

------------------ Uninstalled Packages ------------------
When running if a library or framework is not install you can run "pip3 install <package_name>" 
or "sudo pip3 install <package_name>" and try to rerun the main.py code